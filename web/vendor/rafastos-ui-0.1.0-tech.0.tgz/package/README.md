# @rafastos/ui

Design System Rafastos — pacote técnico **0.1.0-tech.0** (provisório; a Etapa 11 pode alterar aparência via tokens).

## Instalação local (tarball)

```bash
# no repositório Rafastos
npm run build:ui
npm pack --workspace=@rafastos/ui
# ou: cd packages/ui && npm pack

# no projeto consumidor
npm install /caminho/para/rafastos-ui-0.1.0-tech.0.tgz
```

## Estilos (Tailwind 4)

```css
@import "tailwindcss";
@source "../node_modules/@rafastos/ui/dist";
@import "@rafastos/ui/styles.css";
@import "tw-animate-css";
@import "shadcn/tailwind.css";
```

Fontes: defina `--font-space-grotesk` e `--font-ibm-plex-mono` (next/font ou CSS `@font-face` / Google Fonts).

## Tema

```ts
import { applyThemeToDocument, themeInitScript } from "@rafastos/ui";

applyThemeToDocument("dark"); // ou "light" → data-theme + .dark
```

## Tokens / Etapa 11

Sobrescreva variáveis CSS **depois** de `@import "@rafastos/ui/styles.css"`:

```css
:root {
  --rf-cyan-pulse: #22d3ee;
}
html[data-theme="dark"] {
  --rf-action: var(--rf-cyan-pulse);
}
```

Contrato: modelos do estúdio exportam folhas de variáveis (`--rf-*`, aliases shadcn), não patcham `dist/`.

## Imports

```ts
import { Button, Input, Dialog, ChartContainer, Stepper, UrbanListingPattern } from "@rafastos/ui";
import { Button } from "@rafastos/ui/button";
```

Ver `docs/rafastos-ui.md` e `brand/package-exports.json`.

# Third-party notices — @rafastos/ui

## ReUI Stepper

- Source: [ReUI Stepper](https://reui.io/docs/components/radix/stepper) (`@reui/stepper`, style radix-nova)
- License: MIT (see https://github.com/keenthemes/reui/blob/main/LICENSE.md)
- File in this package: `src/reui/stepper.tsx` / `dist/reui/stepper.js`
- Adapted for project ESLint; public API preserved.

## Other runtime libraries

This package depends on (peer or direct) open-source libraries including Radix UI, class-variance-authority, cmdk, embla-carousel-react, input-otp, lucide-react, recharts, motion, sonner, vaul, react-day-picker, and react-resizable-panels. Their respective licenses apply; see each package’s LICENSE in `node_modules` after install.
